package com.example.photostudio

data class ImageItem(val imageResId: Int)
